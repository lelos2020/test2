# GREEK RESIDENTIAL VALUATION - COMPARATIVE METHOD ANALYSIS

## PHASE 1: METHODOLOGY DOCUMENTATION

### Data Sources Analyzed:
1. **NOVAL Kolonaki Report** (46_C_164_04_2023) - 304.87 sqm apartment, 4th floor
2. **Danos Valuation Reports** - Multiple residential comparables
3. **ΣΕΚΕ Textbook 2018** - Theoretical adjustment factors

### Core Adjustment Categories (Greek Practice):

#### 1. **TRANSACTION TYPE** (Δικαιοπραξία / Ζητούμενη τιμή)
- **Range**: -10% to -20%
- **Logic**: Asking prices vs actual transactions
- **Greek Practice**: -15% to -20% typical for asked prices

#### 2. **LOCATION/MARKETABILITY** (Θέση / Εμπορικότητα Σημείου)
- **Range**: ±15% to ±20%
- **Factors**: 
  - Neighborhood quality
  - Proximity to amenities (metro, shops, schools)
  - Street prestige

#### 3. **ACCESS** (Πρόσβαση)
- **Range**: ±5% to ±10%
- **Factors**:
  - Public transport proximity
  - Road access quality
  - Parking availability

#### 4. **POSITION/VIEWS** (Προβολή/Θέα)
- **Range**: 0% to +15%
- **Specific Adjustments**:
  - Acropolis view: +15%
  - Sea view: +10% to +15%
  - Open horizon: +5% to +10%
  - No view: 0%

#### 5. **AGE/CONDITION** (Ηλικία / Κατάσταση / Ανακαίνιση)
- **Age Factor**: ±1.0% to ±2.0% per year
- **Condition Adjustments**:
  - Fully renovated: +10%
  - Good condition: +5%
  - Average condition: 0%
  - Needs renovation: -10% to -15%

**Greek Calculation Method for Age**:
```
Construction Cost = 1,000 €/m²
Construction with common areas = 1,000 × 1.20 = 1,200 €/m²
Sale Price = 2,400 €/m²
Land Value = 1,200 €/m²

Age Factor = [(3% × construction) + (0% × sale price)] / (construction + land)
Age Factor = (3% × 1,200) / 2,400 = 1.5% per year
```

#### 6. **FLOOR LEVEL** (Όροφος)
- **Standard**: ±2% to ±3% per floor
- **Greek Practice**:
  - Ground floor apartments: -10% to -15%
  - Penthouse/Rooftop: +5% to +10%
  - Setback floors (εσοχή): +2% additional

#### 7. **AREA SIZE** (Ανηγμένη Επιφάνεια)
- **Greek Method**: ±1% per 10-50 sqm difference
- **Logic**: Smaller apartments command higher €/sqm
- **NOVAL Practice**: 1% per 25 sqm

**CRITICAL - Greek Weighted Area Calculation**:
```
Main Floor Area: × 1.00
Attic/Loft (σοφίτα/πατάρι): × 0.30 to 0.40
Basement/Storage (υπόγειο/αποθήκη): × 0.20
Semi-basement (ημιυπόγειο): × 0.50
Balconies > 10sqm: × 0.50
```

#### 8. **LIGHT/VENTILATION** (Φωτισμός / Αερισμός)
- **Range**: ±10% to ±15%
- **Categories**:
  - Through apartment (διαμπερές): +10%
  - Corner (γωνιακό): +5%
  - Internal/courtyard facing: -10% to -15%

#### 9. **AMENITIES** (Παροχές/Παρακολουθήματα)
- Parking space: ±3% to ±7%
- Storage: ±3%
- Autonomous heating vs central: +5%
- No elevator (floors 2+): -10%
- Air conditioning: +3%

#### 10. **TIME ON MARKET** (Χρόνος Αγγελίας)
- Fresh listings: 0%
- 3-6 months: -2%
- 6-12 months: -5%
- 12+ months: -10%

### Weighting System (Greek Practice):
- Each comparable receives weight: 17-30%
- More similar comparables receive higher weight
- Typically 4-6 comparables used
- Total weights must equal 100%

