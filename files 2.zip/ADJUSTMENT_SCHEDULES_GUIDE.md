# ADJUSTMENT SCHEDULES - COMPREHENSIVE GUIDE

## Overview

The model now includes **systematic, range-based adjustments** rather than manual percentage inputs. This provides:

- ✅ **Objectivity** - Consistent adjustment methodology
- ✅ **Transparency** - Clear ranges and criteria
- ✅ **Efficiency** - Automatic calculations via lookup tables
- ✅ **Accuracy** - Based on market analysis and industry standards
- ✅ **Flexibility** - Easily customizable ranges

---

## HOW IT WORKS

### 1. Adjustment Schedules Sheet

This sheet contains **9 adjustment lookup tables** that define:
- Value ranges for each characteristic
- Corresponding adjustment percentages
- Descriptions and codes for easy reference

### 2. Automatic Calculations

The **Comparative Method** sheet automatically:
1. Reads property characteristics (from Property Data or user inputs)
2. Looks up the appropriate adjustment from the schedules
3. Calculates the total adjustment factor
4. Applies it to the base market price

---

## ADJUSTMENT SCHEDULES EXPLAINED

### 1. AGE ADJUSTMENT

**How it works:** Model compares the subject property's effective age to defined ranges and applies corresponding adjustment.

| Age Range | Years | Adjustment % |
|-----------|-------|--------------|
| New | 0-2 | +10% |
| Very Recent | 3-5 | +7% |
| Recent | 6-10 | +3% |
| Average | 11-15 | 0% |
| Mature | 16-20 | -3% |
| Old | 21-30 | -7% |
| Very Old | 31-40 | -12% |
| Obsolete | 41+ | -18% |

**Data Source:** Effective Age from Property Data (auto-calculated)

**Customization:** Modify percentages in cells D6:D13 of Adjustment Schedules sheet

---

### 2. CONDITION ADJUSTMENT

**How it works:** Uses VLOOKUP to find adjustment based on condition code entered.

| Code | Condition | Description | Adjustment % |
|------|-----------|-------------|--------------|
| EXC | Excellent | Recently renovated, perfect | +8% |
| VG | Very Good | Well maintained | +4% |
| G | Good | Normal wear | 0% |
| AVG | Average | Some deferred maintenance | -4% |
| F | Fair | Needs repairs | -8% |
| P | Poor | Significant repairs needed | -15% |
| VP | Very Poor | Major structural issues | -25% |

**Data Entry:** Enter code (e.g., "G", "VG") in Comparative Method, cell B11

**Customization:** Modify table in Adjustment Schedules B17:D23

---

### 3. SIZE ADJUSTMENT

**How it works:** Applies economy of scale adjustments based on property size.

| Range | Size (sqm) | Adjustment % |
|-------|------------|--------------|
| Very Small | 0-50 | -8% |
| Small | 51-75 | -4% |
| Average | 76-100 | 0% |
| Above Average | 101-150 | +3% |
| Large | 151-200 | +5% |
| Very Large | 201+ | +7% |

**Data Source:** Total Built Area from Property Data (automatic)

**Rationale:** Smaller units typically command premium per sqm; larger units have economy of scale

---

### 4. FLOOR LEVEL ADJUSTMENT

**How it works:** Adjusts for floor level based on market preferences.

| Floor | Number | Adjustment % |
|-------|--------|--------------|
| Basement | -1 | -12% |
| Ground Floor | 0 | -5% |
| 1st Floor | 1 | 0% |
| 2nd Floor | 2 | +2% |
| 3rd Floor | 3 | +3% |
| 4th Floor | 4 | +4% |
| 5th Floor+ | 5+ | +5% |
| Penthouse | 99 | +10% |

**Data Entry:** Enter floor number in Comparative Method, cell B13
- Use -1 for basement
- Use 99 for penthouse
- Use 0 for ground floor

---

### 5. LOCATION QUALITY ADJUSTMENT

**How it works:** VLOOKUP based on location quality code.

| Code | Location Type | Description | Adjustment % |
|------|---------------|-------------|--------------|
| PC | Prime Central | Best location, prestigious | +15% |
| CC | Central Commercial | Main commercial street | +10% |
| C | Central | Central area, good access | +5% |
| SC | Secondary Central | Near center | +2% |
| A | Average | Standard residential | 0% |
| S | Secondary | Secondary location | -5% |
| P | Peripheral | Outskirts, limited access | -10% |
| R | Remote | Remote, poor access | -15% |

**Data Entry:** Enter code (e.g., "A", "C", "PC") in Comparative Method, cell B14

---

### 6. VIEW QUALITY ADJUSTMENT

**How it works:** VLOOKUP based on view type code.

| Code | View Type | Description | Adjustment % |
|------|-----------|-------------|--------------|
| PSV | Panoramic Sea View | Unobstructed sea/ocean | +12% |
| SV | Sea View | Partial sea view | +8% |
| PV | Park/Green View | Park or green space | +5% |
| OV | Open View | Open unobstructed | +3% |
| SU | Standard Urban | Normal city view | 0% |
| LV | Limited View | Restricted view | -2% |
| PrV | Poor View | Industrial/poor view | -5% |
| NV | No View | No windows/blocked | -8% |

**Data Entry:** Enter code (e.g., "SU", "SV") in Comparative Method, cell B15

---

### 7. PARKING SPACES ADJUSTMENT

**How it works:** Adjusts based on number of parking spaces provided.

| Provision | Spaces | Adjustment % |
|-----------|--------|--------------|
| Multiple Covered | 3+ | +8% |
| Double Covered | 2 | +5% |
| Single Covered | 1 | +3% |
| Single Uncovered | 0.5 | +1% |
| No Parking | 0 | -5% |

**Data Source:** Parking Spaces from Property Data (automatic)

---

### 8. ENERGY PERFORMANCE CERTIFICATE (EPC) ADJUSTMENT

**How it works:** VLOOKUP based on EPC rating.

| Rating | Description | Adjustment % |
|--------|-------------|--------------|
| A+ | Best energy performance | +6% |
| A | Excellent | +4% |
| B | Very good | +2% |
| C | Good | 0% |
| D | Average | -2% |
| E | Below average | -4% |
| F | Poor | -6% |
| G | Very poor | -8% |

**Data Source:** EPC Rating from Property Data (automatic)

---

### 9. AMENITIES SCORE ADJUSTMENT

**How it works:** Adjusts based on overall amenity score (0-10 scale).

| Score | Amenity Level | Description | Adjustment % |
|-------|---------------|-------------|--------------|
| 9-10 | Luxury | Pool, gym, concierge, security | +10% |
| 7-8 | Excellent | Multiple premium amenities | +6% |
| 5-6 | Very Good | Several good amenities | +3% |
| 3-4 | Good | Basic amenities | 0% |
| 1-2 | Minimal | Very few amenities | -3% |
| 0 | None | No amenities | -5% |

**Data Entry:** Rate amenities 0-10 in Comparative Method, cell B18

**Scoring Guide:**
- **Pool:** +2 points
- **Gym/Fitness:** +1 point
- **24h Security:** +1 point
- **Concierge:** +1 point
- **Elevator (in building without):** +1 point
- **Garden/Common areas:** +1 point
- **Storage rooms:** +0.5 points
- **Playground:** +0.5 points
- **Central heating system:** +0.5 points
- **Common parking:** +0.5 points

---

### 10. MARKET TIMING / OTHER ADJUSTMENT

**How it works:** Manual input for special factors not covered by other adjustments.

**Use cases:**
- Market timing differences between subject and comparables
- Recent market trend changes
- Special property features not captured elsewhere
- Pending developments affecting value
- Unique circumstances

**Data Entry:** Enter percentage in Comparative Method, cell B31

---

## CUSTOMIZING ADJUSTMENT SCHEDULES

### To Modify Adjustment Ranges:

1. Go to **Adjustment Schedules** sheet
2. Locate the relevant table (9 tables total)
3. Modify values in YELLOW cells (adjustment percentages)
4. Optionally modify range boundaries in BLUE cells

**Important:** 
- Do NOT modify column B and C headers (these are used in lookups)
- Keep code formats consistent (e.g., all UPPERCASE for location codes)
- Test changes with sample properties

### To Add New Adjustment Factors:

1. Add new table in Adjustment Schedules sheet
2. Update Comparative Method to include new characteristic input
3. Add formula in adjustment calculation section using IF or VLOOKUP
4. Include in total adjustment sum (cell B33)

---

## WORKED EXAMPLE

### Subject Property:
- Age: 8 years
- Condition: Good (G)
- Size: 120 sqm
- Floor: 3rd
- Location: Central (C)
- View: Park View (PV)
- Parking: 2 spaces
- EPC: B rating
- Amenities: Score 6
- Market timing: 0%

### Automatic Calculations:

| Factor | Value | Lookup Result | Adjustment |
|--------|-------|---------------|------------|
| Age | 8 years | 6-10 range | +3.0% |
| Condition | G | Good code | 0.0% |
| Size | 120 sqm | 101-150 range | +3.0% |
| Floor | 3 | 3rd floor | +3.0% |
| Location | C | Central code | +5.0% |
| View | PV | Park view code | +5.0% |
| Parking | 2 | Double covered | +5.0% |
| EPC | B | B rating | +2.0% |
| Amenities | 6 | 5-6 score range | +3.0% |
| Market timing | - | Manual input | 0.0% |
| **TOTAL** | | | **+29.0%** |

### Value Calculation:

```
Base Market Price per sqm: €3,500
Total Adjustment: +29.0%
Adjusted Price per sqm: €3,500 × 1.29 = €4,515
Property Area: 120 sqm
Indicated Value: €4,515 × 120 = €541,800
```

---

## VALIDATION & QUALITY CONTROL

### Reasonableness Checks:

1. **Total Adjustment Range:** Typically between -30% to +40%
   - If outside this range, review individual adjustments
   - Consider if property is truly exceptional or problematic

2. **Individual Adjustment Limits:** Each factor typically ±15%
   - Larger adjustments may indicate inappropriate comparable
   - Consider finding better comparables

3. **Cross-Validation:**
   - Compare adjusted prices from multiple comparables
   - Standard deviation should be < 10% of mean
   - Outliers may indicate adjustment errors

4. **Market Check:**
   - Final value per sqm should align with market data
   - Compare to unadjusted comparable average
   - Verify adjustment logic with market participants

---

## BEST PRACTICES

### For Accurate Adjustments:

1. **Start with Good Comparables**
   - Similar property type
   - Same neighborhood or comparable area
   - Recent transactions (< 6 months)
   - Similar size and quality

2. **Be Conservative**
   - When in doubt, use smaller adjustments
   - Avoid "double-counting" (e.g., EPC already reflected in condition)
   - Consider cumulative effect of multiple adjustments

3. **Document Rationale**
   - Keep notes on why specific codes were selected
   - Document special circumstances for manual adjustments
   - Maintain comparable property details

4. **Calibrate to Market**
   - Periodically validate adjustment ranges against actual transactions
   - Update tables based on market research
   - Consider seasonal or cyclical factors

5. **Use Multiple Comparables**
   - Apply adjustments to 3-5 comparables minimum
   - Average or reconcile adjusted values
   - Gives more reliable indication than single comparable

---

## TROUBLESHOOTING

### Issue: Adjustment seems wrong
**Solution:** 
- Check if correct code/value entered
- Verify lookup table reference in formula
- Review if range boundaries are appropriate

### Issue: VLOOKUP returns 0 or error
**Solution:**
- Ensure exact code match (case-sensitive)
- Check for extra spaces in codes
- Verify table range in formula is correct

### Issue: Total adjustment too high/low
**Solution:**
- Review each individual adjustment
- Consider if property is truly exceptional
- Check for double-counting of factors
- Verify comparable selection is appropriate

### Issue: Different results from manual calculation
**Solution:**
- Formulas use exact cell references - check source data
- Verify all input cells are filled correctly
- Check if property data updated but comparative method not recalculated

---

## INTEGRATION WITH OTHER METHODS

The adjustment schedules primarily enhance the **Comparative Method**, but insights can inform:

### Income Method:
- Location quality → Affects rental rates
- Condition → Impacts operating expenses
- Amenities → Influence rental premium

### Cost Method:
- Age → Physical deterioration rate
- Condition → Functional obsolescence assessment
- EPC → Energy efficiency adjustments

### Residual Method:
- Location → End product pricing
- Size → Development efficiency
- Amenities → GDV calculation

---

## MARKET RESEARCH FOR CALIBRATION

### Recommended Approach:

1. **Collect Transaction Data:**
   - Gather 20-30 recent sales
   - Record all relevant characteristics
   - Note actual transaction prices

2. **Statistical Analysis:**
   - Calculate price per sqm for each
   - Group by characteristic (age, condition, etc.)
   - Calculate average price difference between groups

3. **Update Tables:**
   - Set base case (e.g., age 11-15, condition Good) = 0%
   - Calculate percentage differences for other ranges
   - Round to nearest 0.5% or 1%

4. **Validate:**
   - Apply adjustments to test properties
   - Compare to known sale prices
   - Refine ranges as needed

---

## COMPLIANCE NOTES

### EVS 2016 & IVS Compliance:

The adjustment schedule approach complies with:

✓ **EVS 2016 - Market Value Definition**
- Adjustments reflect market participant behavior
- Based on observable market evidence
- Consistent and transparent methodology

✓ **IVS 105 - Valuation Approaches and Methods**
- Market approach with systematic adjustment
- Documented and defensible methodology
- Appropriate for property valuation

✓ **Best Practice Standards**
- Objective, repeatable process
- Clear documentation of assumptions
- Transparent calculation methodology

### Professional Judgment:

While the model provides systematic calculations, valuers must still apply professional judgment:
- Selection of appropriate base price
- Choice of comparables
- Calibration of adjustment ranges
- Overall reconciliation of value

---

**END OF ADJUSTMENT SCHEDULES GUIDE**

For questions about customizing adjustments for specific markets or property types, consult with experienced valuers or market analysts in your region.

