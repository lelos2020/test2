# COMPREHENSIVE REAL ESTATE VALUATION MODEL
## User Guide & Documentation

**Version:** 1.0  
**Date:** December 2024  
**Based on:** Greek Valuation Methodology (EVS 2016 & IVS Compliant)

---

## TABLE OF CONTENTS

1. [Overview](#overview)
2. [Model Structure](#model-structure)
3. [Getting Started](#getting-started)
4. [Detailed Sheet Instructions](#detailed-sheet-instructions)
5. [Valuation Methods Explained](#valuation-methods-explained)
6. [Best Practices](#best-practices)
7. [Troubleshooting](#troubleshooting)

---

## OVERVIEW

This Excel model provides a comprehensive framework for valuing real estate properties using internationally recognized methodologies as described in the Greek Real Estate Property 2018 manual. The model implements all four primary valuation approaches:

1. **Comparative Method** (Market Approach)
2. **Income Method** (Discounted Cash Flow)
3. **Cost Method** (Depreciated Replacement Cost)
4. **Residual Method** (Development Approach)

### Key Features

- ✅ Fully dynamic and formula-driven (no hardcoded calculations)
- ✅ Professional color-coding system for easy navigation
- ✅ Comprehensive property data inputs
- ✅ Market data integration
- ✅ Multiple valuation approaches
- ✅ Automatic reconciliation with weighting
- ✅ EVS 2016 and IVS compliant
- ✅ Greek methodology implementation

---

## MODEL STRUCTURE

### Color Coding System

The model uses industry-standard color coding:

- **BLUE TEXT** → User inputs and assumptions you can modify
- **BLACK TEXT** → Formulas and calculations (do not modify)
- **GREEN TEXT** → Links to other sheets within the workbook
- **YELLOW BACKGROUND** → Key assumptions requiring attention
- **LIGHT BLUE HEADERS** → Section headers and organization

### Sheet Organization

1. **Summary & Reconciliation** - Executive summary with final concluded value
2. **Control Panel** - Main property information and method selection
3. **Property Data** - Detailed physical characteristics and specifications
4. **Market Data** - Comparable sales and rental data
5. **1. Comparative Method** - Market comparison approach
6. **2. Income Method** - DCF analysis
7. **3. Cost Method** - Replacement cost approach
8. **4. Residual Method** - Development value approach

---

## GETTING STARTED

### Step 1: Property Information (Control Panel)

1. Open the **Control Panel** sheet
2. Enter basic property information:
   - Valuation Date
   - Property ID/Reference
   - Address and Municipality
   - Property Type (Apartment, Office, Retail, Industrial, Land)
   - Property Status (Completed, Under Construction, Land Only)
   - Urban Planning Zone

3. Select valuation basis and purpose:
   - Valuation Basis: Market Value, Fair Value, or Investment Value
   - Purpose: Loan Security, Sale, Financial Reporting, etc.

4. Select which valuation methods to apply (Yes/No for each)

### Step 2: Property Data

1. Navigate to **Property Data** sheet
2. Fill in all BLUE cells:

**Land Data:**
- Land area, shape, dimensions
- Slope, street access, road width

**Building Data:**
- Total built area, floors, units
- Year built, year renovated
- Construction quality and condition
- Energy Performance Certificate rating

**Building Specifications:**
- Elevator, heating, air conditioning
- Parking spaces, storage rooms
- Security and fire safety systems
- Special features and amenities

**Zoning & Planning:**
- Building coefficient
- Coverage ratio
- Maximum height
- Permitted uses

### Step 3: Market Data

1. Open **Market Data** sheet
2. Enter comparable sales data:
   - Address and sale date
   - Sale price and area
   - Age and condition
   - Adjustment factors (%)

3. Enter rental comparables:
   - Address and rent date
   - Monthly rent and area
   - Age and condition
   - Adjustment factors (%)

The model automatically calculates statistical summaries.

### Step 4: Valuation Methods

Work through each valuation method sheet:

#### 1. Comparative Method
- Review market analysis from comparables
- Adjust the base price per sqm if needed
- Modify adjustment factors for:
  - Location quality
  - Age and condition
  - Size, floor level, view
  - Parking, amenities, energy efficiency
  - Market conditions

#### 2. Income Method
- Review and adjust key assumptions:
  - Vacancy rate (%)
  - Operating expenses (% of income)
  - Rental growth rate (%)
  - Discount rate (%)
  - Terminal cap rate (%)
  - Projection period (years)
- The model generates a 10-year DCF projection

#### 3. Cost Method
- Set land value per sqm
- Set construction cost per sqm
- Set professional fees percentage
- Adjust depreciation factors:
  - Total economic life
  - Functional obsolescence
  - External obsolescence

#### 4. Residual Method
- Enter development area (sqm)
- Set expected sale price per sqm for completed development
- Enter construction cost per sqm
- Set professional fees, marketing costs, contingency
- Define development period and finance rate
- Set developer's profit margin

### Step 5: Reconciliation

1. Navigate to **Summary & Reconciliation** sheet
2. Review all indicated values from each method
3. Adjust the **Weight %** for each method in YELLOW cells:
   - Weights must total 100%
   - Typical weightings:
     - Comparative: 30-50% (most common)
     - Income: 25-40% (for income-producing)
     - Cost: 10-20% (supporting role)
     - Residual: 5-15% (development potential)
4. Review the final **Reconciled Market Value**

---

## VALUATION METHODS EXPLAINED

### 1. Comparative Method (Market Approach)

**When to use:**
- Sufficient comparable sales exist
- Active market with reliable transaction data
- Standard property types (apartments, offices, retail)

**Methodology:**
- Collects comparable sales data
- Adjusts for differences between subject and comparables
- Applies adjustment factors for location, condition, features
- Calculates adjusted price per sqm
- Multiplies by subject property area

**Key Inputs:**
- Market comparables (min. 3-5)
- Adjustment factors (typically -10% to +10%)
- Base price per sqm selection

**Reliability:** HIGH for most property types with active markets

---

### 2. Income Method (DCF Approach)

**When to use:**
- Income-producing properties
- Investment properties
- Commercial, office, retail spaces
- Multi-unit residential

**Methodology:**
- Projects 10-year cash flows
- Calculates Net Operating Income (NOI)
- Discounts future cash flows to present value
- Adds terminal value (reversion)
- Sums all present values

**Key Inputs:**
- Annual rental income (from market data)
- Vacancy rate (typically 3-10%)
- Operating expenses (typically 20-35% of EGI)
- Discount rate (required return, typically 6-10%)
- Terminal cap rate (typically 5-8%)
- Rental growth rate (typically 1-3%)

**Formula:**
```
PV = Σ (NOI_t / (1+r)^t) + (Terminal Value / (1+r)^n)
Terminal Value = NOI_(n+1) / Cap Rate
```

**Reliability:** HIGH for income-producing properties with stable leases

---

### 3. Cost Method (DRC Approach)

**When to use:**
- New or recently built properties
- Special purpose properties
- Properties with limited comparables
- Insurance valuations
- Financial reporting

**Methodology:**
- Values land separately (via comparables)
- Calculates replacement cost of building
- Deducts depreciation:
  - Physical deterioration (age-based)
  - Functional obsolescence (design deficiencies)
  - External obsolescence (location/market)
- Adds land value to depreciated building value

**Key Inputs:**
- Land value per sqm
- Construction cost per sqm (current costs)
- Professional fees (typically 10-20%)
- Total economic life (typically 40-60 years)
- Effective age
- Obsolescence adjustments

**Formula:**
```
Market Value = Land Value + (Replacement Cost × (1 - Total Depreciation%))
```

**Reliability:** MEDIUM - Most reliable for new buildings, less so for older properties

---

### 4. Residual Method (Development Approach)

**When to use:**
- Development sites
- Properties to be demolished/redeveloped
- Land valuation
- Feasibility studies

**Methodology:**
- Calculates Gross Development Value (completed project)
- Deducts all development costs
- Deducts finance costs
- Deducts developer's profit
- Residual amount = Land Value

**Key Inputs:**
- Building coefficient (from zoning)
- Development area
- Sale price per sqm (of completed development)
- Construction cost per sqm
- Professional fees, marketing, contingency
- Development period
- Finance rate
- Developer's profit (typically 15-25% of GDV)

**Formula:**
```
Land Value = GDV - Construction Costs - Professional Fees - 
             Marketing - Contingency - Finance Costs - Developer's Profit
```

**Reliability:** MEDIUM - Sensitive to assumptions, best used with other methods

---

## BEST PRACTICES

### Input Guidelines

1. **Always use current market data**
   - Update comparables regularly
   - Use transactions from last 6-12 months
   - Adjust for market changes if older data

2. **Be conservative with assumptions**
   - Use realistic vacancy rates
   - Don't overestimate rental growth
   - Use market-supported discount rates

3. **Validate cross-method consistency**
   - Check if all methods yield similar values
   - High variance suggests review needed
   - Coefficient of Variation < 15% is good

4. **Document your assumptions**
   - Note sources for key inputs
   - Explain adjustment rationale
   - Keep comparable property details

### Weighting Methodology

**General Guidelines:**
- Give highest weight to most reliable method
- Consider property type and market conditions
- Reduce weight if limited data availability

**Typical Weights by Property Type:**

**Standard Apartment/Condo:**
- Comparative: 50-60%
- Income: 25-35%
- Cost: 10-15%
- Residual: 0-5%

**Commercial Income Property:**
- Income: 45-55%
- Comparative: 30-40%
- Cost: 10-15%
- Residual: 0-5%

**New Construction:**
- Cost: 40-50%
- Comparative: 30-40%
- Income: 10-20%
- Residual: 0-10%

**Development Land:**
- Residual: 50-60%
- Comparative: 30-40%
- Income: 0-10%
- Cost: 0%

### Quality Checks

Before finalizing:

1. ✓ All BLUE cells completed
2. ✓ No #REF!, #DIV/0!, or formula errors
3. ✓ Weights sum to 100%
4. ✓ Values from different methods are within reasonable range
5. ✓ Value per sqm aligns with market expectations
6. ✓ Income yields are market-appropriate (if applicable)
7. ✓ All assumptions documented and justified

---

## TROUBLESHOOTING

### Common Issues

**Issue: Formula errors (#REF!, #DIV/0!)**
- **Cause:** Missing input data or deleted cells
- **Solution:** Check all BLUE cells are filled; restore any accidentally deleted cells

**Issue: Weights don't sum to 100%**
- **Cause:** Incorrect weight allocation
- **Solution:** Check Summary sheet, cell shows "⚠ Adjust weights"

**Issue: Negative or unrealistic values**
- **Cause:** Incorrect inputs or assumptions
- **Solution:** Review Cost Method depreciation, Income Method expenses, Residual Method costs

**Issue: Large variance between methods**
- **Cause:** Inconsistent assumptions or data quality
- **Solution:** Review each method's inputs; check market data validity

**Issue: DCF shows very high/low value**
- **Cause:** Unrealistic discount rate or rental assumptions
- **Solution:** Verify discount rate is market-appropriate (typically 6-10%); check rental income against market data

### Validation Tests

Run these checks:

1. **Comparative Method:**
   - Value per sqm within ±20% of market average
   - Adjustment factors reasonable (-15% to +15%)

2. **Income Method:**
   - Gross yield 4-8% for residential
   - Net yield 2.5-5% for residential
   - Higher for commercial properties

3. **Cost Method:**
   - Depreciation not exceeding 80% for occupied buildings
   - Land value ≥ 25% of total value (typically)

4. **Residual Method:**
   - Land value positive
   - Land value per sqm aligns with comparable land sales

---

## ADDITIONAL NOTES

### Compliance & Standards

This model is designed to comply with:
- **European Valuation Standards (EVS 2016)**
- **International Valuation Standards (IVS)**
- **Greek Valuation Methodology (REV 2018)**

### Limitations

- Model is a tool to assist valuation; professional judgment required
- Results depend on accuracy of inputs
- Market conditions change; regular updates needed
- Specialized properties may require additional analysis
- Legal and planning constraints must be verified independently

### Support & Updates

For questions or model enhancements:
- Review the methodology in "Real Estate Property 2018" manual
- Consult with certified valuers (REV) for complex cases
- Update market data quarterly at minimum

---

## APPENDIX: FORMULA REFERENCE

### Key Calculations

**Comparative Method:**
```
Adjusted Price/sqm = Base Price × (1 + Total Adjustments%)
Market Value = Adjusted Price/sqm × Property Area
```

**Income Method:**
```
NOI = (Gross Potential Income × (1 - Vacancy Rate)) × (1 - Operating Expenses%)
Present Value = Σ(NOI_t / (1 + Discount Rate)^t)
Terminal Value = NOI_Year11 / Terminal Cap Rate
Market Value = Sum of PV + PV of Terminal Value
```

**Cost Method:**
```
Replacement Cost = Area × Construction Cost/sqm × (1 + Professional Fees%)
Physical Depreciation% = Effective Age / Total Economic Life
Depreciated Value = Replacement Cost × (1 - Total Depreciation%)
Market Value = Land Value + Depreciated Building Value
```

**Residual Method:**
```
GDV = Development Area × Sale Price/sqm
Total Costs = Construction + Fees + Marketing + Contingency
Finance Costs = Total Costs × (Period/12) × Finance Rate
Developer's Profit = GDV × Profit%
Land Value = GDV - Total Costs - Finance Costs - Developer's Profit
```

---

**END OF USER GUIDE**

For technical support or questions about the Greek valuation methodology, please consult with a certified REV (Registered Expert Valuer) in Greece.

