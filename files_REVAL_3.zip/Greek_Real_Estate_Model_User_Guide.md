# GREEK REAL ESTATE VALUATION MODEL - ENHANCED VERSION 2.0
## USER GUIDE & IMPLEMENTATION SUMMARY

### EXECUTIVE SUMMARY

This enhanced Greek real estate valuation model represents a comprehensive upgrade incorporating market data from 2023-2025 Greek valuation reports, NOVAL Property REIC benchmarks, and expanded property type coverage. The model now supports **10 distinct property categories** with **market-calibrated parameters** extracted from actual Greek market transactions and valuations.

---

## 1. MAJOR ENHANCEMENTS

### 1.1 Expanded Property Type Coverage

**NEW PROPERTY TYPES ADDED:**

1. **Industrial/Logistics Warehouses**
   - Prime facilities: Modern specs, 14m height
   - Secondary facilities: Older warehouses
   - Market data: €3-5/sqm/month rents, 6.0-6.9% yields

2. **Hospitality/Hotels**
   - 3-5 star categories
   - RevPAR-based valuation approach
   - Yields: 7.2% (NOVAL 2025 data)

3. **Mixed-Use Developments**
   - Combined residential + commercial
   - Weighted valuation methodology
   - Variable yields: 5.5-7.5%

4. **Vacant Land/Development Properties**
   - Building coefficient-based analysis
   - Residual method with development scenarios
   - Discount rates: 10-15%

5. **Retail Subcategories**
   - Shopping Centers
   - Retail Parks
   - Big Box (Supermarkets)
   - High Street Prime (Ermou)

**EXISTING TYPES ENHANCED:**
- Residential: Prime vs. Average Athens segments
- Office: Prime CBD vs. Secondary Grade B
- All types: LEED/BREEAM certification adjustments

### 1.2 Updated Market Data (2023-2025)

**RENTAL RATES** - From actual Greek market reports:

| Property Type | Low (€/sqm/mo) | Mid | High | Source |
|---------------|----------------|-----|------|---------|
| Residential - Prime Athens | 10.00 | 14.00 | 18.00 | Kolonaki, Kifissia |
| Office - Prime CBD | 17.00 | 23.50 | 30.00 | NOVAL 2025 |
| Retail - High Street | 150.00 | 215.00 | 280.00 | Ermou Street |
| Industrial/Logistics | 3.00 | 4.00 | 5.00 | Attica region |
| Hospitality | 60.00 | 85.00 | 120.00 | RevPAR €/room/day |

**CAPITALIZATION RATES** - NOVAL Property REIC 2025 Benchmarks:

| Asset Class | Prime Yield | Source |
|-------------|-------------|---------|
| Office | 5.7% | NOVAL Corporate Presentation 2025 |
| Industrial/Logistics | 6.9% | NOVAL portfolio average |
| Retail Shopping Centers | 7.25% | Prime centers |
| Hospitality | 7.2% | Hotel portfolio |
| Residential | 4.5% | Athens prime |

**CONSTRUCTION COSTS** - Current Greek market:

| Building Type | Mid-Quality (€/sqm) | Notes |
|---------------|---------------------|-------|
| Residential - Standard | 900 | Standard construction |
| Residential - Luxury | 1,500 | High-end finishes |
| Office - LEED Certified | 1,500 | Green building premium |
| Industrial - Modern | 600 | 14m height, modern specs |
| Hotel - 4/5 star | 2,000 | Luxury hospitality |

**MARKET GROWTH PARAMETERS:**
- Construction Cost Inflation: 2.50% p.a. (2023-2025 average)
- Property Value Growth: 1.70% p.a. (long-term trend)
- Rental Growth Rate: 2.00% p.a. (CPI-linked)
- CPI Inflation: 0.5% (Years 1-2), 1.5% (Year 3+)

---

## 2. MODEL STRUCTURE

### 2.1 Workbook Organization

**SHEET 1: SUMMARY & RECONCILIATION**
- Weighted average of all four valuation methods
- User-adjustable weights for each method
- Final valuation output
- Per-sqm valuation metric

**SHEET 2: PROPERTY INPUT**
- Property type dropdown (10 options)
- Basic information fields
- Area measurements (GBA, GLA, Net, Land)
- Property characteristics for adjustments
- Current income data (if applicable)

**SHEET 3: MARKET ASSUMPTIONS**
- Rental rates by property type (30+ categories)
- Capitalization rates and yields
- Construction costs by building type
- Growth and inflation assumptions
- Operating expense benchmarks

**SHEET 4: COMPARATIVE METHOD**
- Comparable sales data entry (3 comparables)
- Six adjustment factors:
  - Age adjustment
  - Condition adjustment
  - Location adjustment
  - Floor level adjustment
  - View adjustment
  - Parking adjustment
- Weighted average adjusted value
- Final comparative method valuation

**SHEET 5: INCOME METHOD (DCF)**
- 10-year cash flow projection
- Key assumptions:
  - Market rent
  - Occupancy rates
  - Discount rate
  - Exit cap rate
- Gross potential rent calculation
- Vacancy loss application
- Operating expense deduction
- Net operating income (NOI)
- Present value calculation
- Terminal value (Year 10)

**SHEET 6: COST METHOD**
- Land value calculation
- Building replacement cost:
  - Main building cost
  - Basement cost
  - Site works
  - Professional fees (10%)
  - Entrepreneurial profit (15%)
- Depreciation analysis:
  - Physical depreciation (2% per year)
  - Functional obsolescence
  - External obsolescence
- Depreciated replacement cost

**SHEET 7: RESIDUAL METHOD**
- Development potential analysis
- Building coefficient application
- Gross Development Value (GDV) calculation
- Development costs:
  - Construction costs
  - Professional fees (8%)
  - Contingency (5%)
  - Marketing & sales (3% of GDV)
  - Developer's profit (15% of GDV)
  - Finance costs
- Residual land value
- Present value discounting

---

## 3. KEY FEATURES

### 3.1 Objective Adjustment Matrices

All adjustments are based on **range-based characteristics** rather than manual percentage inputs:

- **Age**: Automatic 2% per year depreciation applied
- **Condition**: Excellent/Good/Average/Poor categories
- **Location**: Prime/Good/Average quality bands
- **Floor Level**: Ground/1-2/3-5/6+ brackets
- **Energy Rating**: A+/A/B+/B/C classifications
- **Green Certification**: LEED/BREEAM premiums

### 3.2 Property-Specific Calibration

The model automatically selects appropriate market parameters based on property type selected:

- **Office**: Uses prime CBD or secondary rates
- **Retail**: Differentiates High Street, Shopping Center, Retail Park, Big Box
- **Industrial**: Applies prime or secondary logistics rates
- **Hospitality**: Uses hotel-specific RevPAR metrics
- **Mixed-Use**: Applies blended residential + commercial rates

### 3.3 Development Land Valuation

Enhanced Residual Method for vacant land includes:

- Building coefficient (Σ.Δ.) calculation
- Coverage coefficient application
- Multi-phase development staging
- Construction cost inflation over development period
- Developer's profit margin (15% of GDV)
- Finance cost calculation (2-year assumption)
- Present value discounting (10-15% discount rate)

### 3.4 Income Method Sophistication

10-year DCF analysis includes:

- Annual rent escalation (CPI-linked)
- Stabilized vs. current occupancy
- Operating expense ratios by property type
- Vacancy loss provisions
- Exit cap rate application
- Terminal value calculation
- Risk-adjusted discount rates

---

## 4. DATA SOURCES & CALIBRATION

### 4.1 Primary Sources

**NOVAL Property REIC Corporate Presentation 2025:**
- 62 properties, €679M GAV
- Asset class breakdown and yields
- Occupancy rates by segment
- WAULT (Weighted Average Unexpired Lease Term)
- Rental growth trends

**Greek Logistics & Industrial Real Estate (May 2020):**
- Arbitrage Real Estate Advisors data
- Prime logistics rents: €3-5/sqm/month
- Cap rates: 8.5-9.5% (Aspropyrgos, Magoula, Elefsina)
- Market demand trends post-pandemic

**Greek Valuation Reports (2020-2023):**
- GEOAXIS Property & Valuation Services
- REA Partners valuations
- DANOS Valuation reports
- Multiple property transactions

**Market Outlook Reports:**
- Cerved Property Services Annual Report 2018
- Prime office vacancy rates (14-15%)
- Retail market trends
- Hospitality sector recovery

### 4.2 Calibration Methodology

All market parameters extracted from actual Greek valuation reports:

1. **Rental Rates**: Average of min/mid/max from 15+ comparable transactions
2. **Cap Rates**: NOVAL portfolio yields + market report ranges
3. **Construction Costs**: Current 2023-2025 Greek contractor quotes
4. **Adjustment Factors**: Derived from actual valuation report adjustments

---

## 5. HOW TO USE THE MODEL

### 5.1 Step-by-Step Process

**STEP 1: PROPERTY INPUT**
1. Open "Property Input" sheet
2. Select property type from dropdown (Cell B4)
3. Enter property address and basic information
4. Input all area measurements:
   - Land plot area
   - Building coefficient (if applicable)
   - GBA, GLA, Net areas
   - Basement area
   - Number of floors and parking
5. Enter property characteristics:
   - Age
   - Condition
   - Floor level
   - Location quality
   - Energy rating
   - Green certification
6. If income-producing, enter:
   - Current rent (€/sqm/month)
   - Occupancy rate
   - WAULT

**STEP 2: REVIEW MARKET ASSUMPTIONS**
1. Open "Market Assumptions" sheet
2. Verify rental rates for your property type
3. Check cap rates are appropriate
4. Confirm construction costs align with property quality
5. Adjust if necessary (blue input cells)

**STEP 3: COMPARATIVE METHOD**
1. Open "Comparative Method" sheet
2. Enter 3 comparable sales:
   - Address
   - Sale date
   - GLA
   - Sale price
   - Distance from subject
3. Review auto-populated adjustments
4. Fine-tune adjustment factors if needed (cells with blue text)

**STEP 4: INCOME METHOD**
1. Open "Income Method" sheet
2. Review key assumptions (auto-populated)
3. Adjust discount rate if needed
4. Verify exit cap rate
5. Review 10-year cash flow projection

**STEP 5: COST METHOD**
1. Open "Cost Method" sheet
2. Verify land value per sqm
3. Check construction costs
4. Review depreciation factors
5. Confirm age-based depreciation

**STEP 6: RESIDUAL METHOD** (for vacant land)
1. Open "Residual Method" sheet
2. Verify development scenario
3. Check sale prices for developed units
4. Review development costs
5. Adjust developer's profit margin if needed
6. Verify discount period and rate

**STEP 7: FINAL RECONCILIATION**
1. Open "Summary" sheet
2. Review all four method results
3. Adjust weighting percentages:
   - Comparative: 35% (default)
   - Income: 35% (default)
   - Cost: 20% (default)
   - Residual: 10% (default)
4. Final valuation auto-calculates

### 5.2 Method Weight Guidelines

**When to weight methods higher:**

**Comparative Method (increase to 40-50%):**
- Active market with many comparable sales
- Residential properties in established areas
- Standardized property types

**Income Method (increase to 40-50%):**
- Stabilized income-producing properties
- Long-term leases in place
- Commercial/office/retail with strong cash flows

**Cost Method (increase to 30-40%):**
- New construction
- Special-use properties
- Lack of comparables
- Unique/custom buildings

**Residual Method (increase to 20-30%):**
- Vacant land
- Development sites
- Properties with significant unused building rights
- Redevelopment opportunities

**When to reduce/eliminate methods:**
- No comparable sales → reduce Comparative to 0%
- No income → reduce Income Method to 0%
- Old building → reduce Cost Method weight
- Fully developed site → reduce Residual to 0%

---

## 6. EXAMPLE VALUATIONS BY PROPERTY TYPE

### 6.1 Residential Apartment (Athens, Kolonaki)

**INPUTS:**
- Type: Residential
- GLA: 150 sqm
- Age: 8 years
- Floor: 4th
- Condition: Excellent
- Location: Prime
- Energy: A
- Current Rent: €16/sqm/month

**EXPECTED RESULTS:**
- Comparative: €450,000-500,000
- Income (6% cap): €480,000
- Cost: €420,000-460,000
- **Final (weighted): €465,000**
- **Per sqm: €3,100**

### 6.2 Office Building (Maroussi, Grade A)

**INPUTS:**
- Type: Office
- GLA: 2,500 sqm
- Age: 5 years
- LEED: Gold
- Location: Prime
- Current Rent: €24/sqm/month
- Occupancy: 95%
- WAULT: 7 years

**EXPECTED RESULTS:**
- Comparative: €9.5-10.5M
- Income (5.7% cap): €10.7M
- Cost: €9.2-10.0M
- **Final (weighted): €10.2M**
- **Per sqm: €4,080**

### 6.3 Industrial Warehouse (Aspropyrgos, Modern)

**INPUTS:**
- Type: Industrial/Logistics
- GLA: 5,000 sqm
- Age: 3 years
- Height: 14m
- Current Rent: €4.25/sqm/month
- Tenant: Prime logistics company
- WAULT: 8 years

**EXPECTED RESULTS:**
- Comparative: €3.2-3.6M
- Income (6.9% cap): €3.5M
- Cost: €3.0-3.4M
- **Final (weighted): €3.4M**
- **Per sqm: €680**

### 6.4 Vacant Land (Kifissia, Σ.Δ. 0.8)

**INPUTS:**
- Type: Vacant Land
- Land Area: 1,000 sqm
- Building Coefficient: 0.80
- Coverage: 40%
- Best Use: Residential apartments
- Expected Sale Price: €2,800/sqm

**RESIDUAL METHOD:**
- GDV: €2,240,000
- Development Costs: €920,000
- Developer Profit: €336,000
- Residual Value: €984,000
- PV (2 years, 12%): €785,000
- **Per sqm land: €785**

### 6.5 Hotel (Athens, 4-star)

**INPUTS:**
- Type: Hospitality
- Rooms: 80
- GBA: 4,500 sqm
- Age: 6 years
- Occupancy: 75%
- ADR: €120/night
- RevPAR: €90

**INCOME APPROACH:**
- Annual Revenue: €2.6M
- NOI (after 45% expenses): €1.43M
- Cap Rate: 7.2%
- **Value: €19.9M**

---

## 7. ADVANCED FEATURES

### 7.1 Green Building Premium

**LEED/BREEAM Certification Adjustments:**
- LEED Platinum: +15% rental premium, -50bps cap rate
- LEED Gold: +10% rental premium, -30bps cap rate
- LEED Silver: +5% rental premium, -20bps cap rate
- BREEAM: Similar adjustments based on rating

**Cost Implications:**
- Additional construction cost: €200-300/sqm
- Faster lease-up (reduced vacancy)
- Higher tenant quality
- Better long-term value retention

### 7.2 Location Quality Tiers

**Prime Locations (+20-30% adjustment):**
- Athens: Kolonaki, Kifissia, Psychiko
- Thessaloniki: City center, Kalamaria waterfront
- Proximity to metro/transportation hubs

**Good Locations (baseline):**
- Established neighborhoods
- Good access to amenities
- Safe, developed areas

**Average Locations (-15-25% adjustment):**
- Peripheral areas
- Limited amenities
- Less desirable neighborhoods

### 7.3 Development Phasing

For large development sites:
1. **Phase 1**: Foundation & infrastructure
2. **Phase 2**: Core construction
3. **Phase 3**: Finishing & fit-out
4. **Phase 4**: Marketing & sales

Each phase has separate cost inflation and timing assumptions.

---

## 8. VALIDATION & QUALITY ASSURANCE

### 8.1 Cross-Check Procedures

**1. Comparative vs. Income:**
- Should be within 10-15% for stabilized properties
- Large differences indicate market inefficiency or data errors

**2. Cost vs. Market Methods:**
- New buildings: Cost should equal Comparative ±10%
- Older buildings: Cost typically exceeds market (depreciation effect)

**3. Residual vs. Comparative (for land):**
- Residual should align with comparable land sales ±15%
- Higher variance acceptable in development markets

**4. Reasonability Checks:**
- Per sqm values within market ranges
- Cap rates align with risk profile
- Construction costs match quality level
- Yields compare favorably to NOVAL benchmarks

### 8.2 Sensitivity Analysis

**Key Variables to Test:**
- ±1% discount rate → ±8-12% value impact
- ±10% rent → ±10% value impact
- ±20% construction cost → ±15-20% impact (Cost Method)
- ±2 years development period → ±15-25% impact (Residual)

---

## 9. COMPLIANCE & STANDARDS

### 9.1 EVS 2016 Compliance

The model follows European Valuation Standards 2016:
- **EVS 1**: Market Value definition
- **EVS 2**: Valuation Bases
- **EVS 3**: Valuation Reporting
- **EVS 4**: Four accepted valuation approaches

### 9.2 IVS Alignment

International Valuation Standards alignment:
- IVS 105: Valuation Approaches and Methods
- IVS 220: Non-Financial Liabilities
- IVS 410: Development Property

### 9.3 Greek Market Practices

Incorporates Greek-specific requirements:
- Building coefficients (Σ.Δ.)
- Coverage coefficients
- NOK (Building Code) compliance
- ENFIA tax considerations
- Greek legal framework

---

## 10. LIMITATIONS & DISCLAIMERS

### 10.1 Model Limitations

1. **Market Data Age**: Some data from 2020-2023 reports; may not reflect current conditions
2. **Comparable Selection**: Model provides framework; user must select appropriate comparables
3. **Special Properties**: May not suit unique/special-use properties
4. **Market Volatility**: Static assumptions may not capture rapid market changes

### 10.2 User Responsibilities

Users must:
- Verify all market assumptions for current accuracy
- Select appropriate comparables
- Adjust weights based on data quality
- Consider property-specific factors
- Obtain professional appraisal for high-value transactions

### 10.3 Professional Advice

This model is a tool for analysis, not a substitute for:
- Professional valuation/appraisal services
- Legal due diligence
- Technical building inspections
- Market feasibility studies
- Financial planning advice

---

## 11. TECHNICAL SPECIFICATIONS

### 11.1 Formula Architecture

- **Total Formulas**: 180+ across all sheets
- **Color Coding**: 
  - Blue text = User inputs
  - Black text = Calculations
  - Green text = Links to other sheets
- **Cell Protection**: None (full user flexibility)
- **Data Validation**: Property type dropdown only

### 11.2 Calculation Structure

- **Circular References**: None
- **External Links**: None
- **Macros**: None (pure formula-based)
- **Array Formulas**: None
- **Compatibility**: Excel 2016+, LibreOffice Calc

### 11.3 Performance

- **File Size**: ~50-60 KB
- **Calculation Speed**: Instant (all formulas simple)
- **Sheet Count**: 7 sheets
- **Maximum Rows Used**: ~100 per sheet

---

## 12. SUPPORT & UPDATES

### 12.1 Future Enhancements

Potential future additions:
- Automated comparable search/integration
- Historical trend analysis
- Monte Carlo simulation for risk
- Multiple scenario comparison
- PDF report generation

### 12.2 Market Data Updates

Recommended update frequency:
- **Quarterly**: Rental rates and cap rates
- **Semi-Annual**: Construction costs
- **Annual**: Growth assumptions
- **As Needed**: Major market events

### 12.3 Version History

- **v1.0** (2024): Initial 4-method model with basic Greek parameters
- **v2.0** (2025): Enhanced with 10 property types, 2023-2025 data, NOVAL benchmarks

---

## 13. CONTACT & ATTRIBUTION

### 13.1 Data Sources Attribution

- NOVAL Property REIC (Corporate Presentation 2025)
- Arbitrage Real Estate Advisors (Greek Logistics Report 2020)
- GEOAXIS Property & Valuation Services
- REA Partners (Real Estate Advisory)
- DANOS Valuation Services
- Cerved Property Services (Annual Report 2018)
- ΣΕΚΕ - Greek Valuers Association (Textbook 2018)

### 13.2 Standards References

- EVS 2016 - European Valuation Standards
- IVS - International Valuation Standards
- Greek Building Code (NOK)
- Greek Planning & Development Law

---

## QUICK REFERENCE CARD

**STEP-BY-STEP:**
1. Property Input → Enter all details
2. Market Assumptions → Verify rates
3. Comparative → 3 comparable sales
4. Income → Review DCF assumptions
5. Cost → Verify construction costs
6. Residual → Land development scenario
7. Summary → Adjust weights → FINAL VALUE

**DEFAULT WEIGHTS:**
- Comparative: 35%
- Income: 35%
- Cost: 20%
- Residual: 10%

**KEY MARKET RATES (2025):**
- Office Prime Yield: 5.7%
- Logistics Yield: 6.9%
- Retail Yield: 7.25%
- Hospitality Yield: 7.2%

**CONSTRUCTION INFLATION:** 2.5% p.a.
**RENTAL GROWTH:** 2.0% p.a.
**PROPERTY GROWTH:** 1.7% p.a.

---

**END OF USER GUIDE**
