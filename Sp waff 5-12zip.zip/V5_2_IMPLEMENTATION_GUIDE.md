# S&P WAFF/WALS MODEL V5.2 - IMPLEMENTATION GUIDE

## 🚀 QUICK START

**Model Status:**
- ✅ Parameters: 100% S&P Methodology Compliant
- ⚠️ Formulas: Require manual updates (this guide)
- 📊 Target: Submission-grade S&P WAFF/WALS calculations

**What's Been Done (v5.2):**
- All adjustment parameters updated to S&P methodology values
- Comprehensive tier tables added (CCJ, Arrears, Seasoning, IO)
- Geographic Concentration and Small Pool parameters added
- Income Multiple joint borrower thresholds added

**What You Need to Do:**
- Update formulas in FF Calculations sheet (8 adjustments)
- Update Loss Severity formula in LS Calculations sheet
- Add Geographic Concentration calculation to Pool Summary
- Add Small Pool adjustment to Pool Summary

---

## 📋 FORMULA UPDATE CHECKLIST

### Priority: CRITICAL (Must complete before use)

#### 1. Help to Buy (HTB) Adjustment
**Location:** FF Calculations sheet, Column for HTB adjustment

**Current Status:**
- Parameter value: ✅ Updated to 1.35x
- Formula: ⚠️ Needs FTB exclusion logic

**Required Changes:**

**A. Main HTB formula** (already references correct parameter):
```excel
Current: ='FF Adj Parameters'!$B$37  (now returns 1.35)
Status: ✅ Automatic - no change needed
```

**B. FTB exclusion** (Critical - must add):
```excel
Current FTB formula:
=IF(AND('Loan Tape (S&P)'!U5="Yes", AW5<18), 
    'FF Adj Parameters'!$B$33, 
    1.00)

Updated FTB formula (add HTB check):
=IF(AND('Loan Tape (S&P)'!U5="Yes",
        'Loan Tape (S&P)'!T5<>"Yes",  ← Add this line (exclude HTB)
        'Loan Tape (S&P)'!AW5<'FF Adj Parameters'!$B$124),
    'FF Adj Parameters'!$B$33,
    1.00)
```

**C. LTV Verification** (Data quality check):
```
Verify loan tape Current Balance excludes HTB government equity loan
If HTB equity is included in balance:
  1. Create calculated field: Lender_Balance = Current_Balance - HTB_Equity
  2. Recalculate OLTV and CLTV using lender balance only
```

**Testing:** HTB loan should get 1.35x HTB adjustment AND 1.00x FTB (no FTB benefit)

---

#### 2. Arrears Adjustment
**Location:** FF Calculations sheet, Column for Arrears adjustment

**Current Status:**
- Parameters: ✅ Full scale added (1.00x-15.00x)
- Formula: ⚠️ Must update to reference new tiers

**Required Changes:**

```excel
Replace current formula with:

=LET(
    arrears_months, 'Loan Tape (S&P)'!AK5,
    
    IF(arrears_months=0, 'FF Adj Parameters'!$B$[Arr_0_Row],      // 1.00
    IF(arrears_months=1, 'FF Adj Parameters'!$B$[Arr_1_Row],      // 3.00
    IF(arrears_months=2, 'FF Adj Parameters'!$B$[Arr_2_Row],      // 5.00
    IF(arrears_months=3, 'FF Adj Parameters'!$B$[Arr_3_Row],      // 8.00
    IF(arrears_months=4, 'FF Adj Parameters'!$B$[Arr_4_Row],      // 10.00
    IF(arrears_months=5, 'FF Adj Parameters'!$B$[Arr_5_Row],      // 12.00
    'FF Adj Parameters'!$B$[Arr_6plus_Row]))))))                  // 15.00
)
```

**Row Numbers:** Find the exact row numbers in FF Adj Parameters where:
- "Arrears - Current / 0 months" = 1.00 (e.g., Row 65)
- "Arrears - 1 month" = 3.00 (e.g., Row 66)
- etc.

**Testing:** 
- 0 months = 1.00x
- 3 months = 8.00x
- 6+ months = 15.00x

---

#### 3. CCJ Adjustment
**Location:** FF Calculations sheet, Column for CCJ adjustment

**Current Status:**
- Parameters: ✅ Full tier table added
- Formula: ⚠️ Must rebuild with age/value/count logic

**Required Changes (Complex - 3 components):**

```excel
=LET(
    // 1. Aggregate across borrowers
    ccj_count, 'Loan Tape (S&P)'!AB5 + 'Loan Tape (S&P)'!AC5,
    ccj_value, 'Loan Tape (S&P)'!CCJ_Value_Total,  // Create if needed
    ccj_date, 'Loan Tape (S&P)'!AD5,
    cutoff_date, 'Control Panel'!$B$8,
    ccj_age_years, IF(ccj_count>0, DATEDIF(ccj_date, cutoff_date, "Y"), 999),
    
    // 2. Determine age/value tier
    age_value_tier, 
    IF(ccj_count=0, 1.00,
    IF(ccj_age_years>6, 'FF Adj Parameters'!$B$[CCJ_gt6yr_Row],        // 1.075
    IF(ccj_age_years>=4, 'FF Adj Parameters'!$B$[CCJ_4to6yr_Row],      // 1.30
    IF(ccj_age_years>=2, 'FF Adj Parameters'!$B$[CCJ_2to4yr_Row],      // 1.50
    // Age <2 years - value-based
    IF(ccj_value<500, 'FF Adj Parameters'!$B$[CCJ_lt500_Row],          // 1.60
    IF(ccj_value<1000, 'FF Adj Parameters'!$B$[CCJ_500to1k_Row],       // 2.00
    IF(ccj_value<2000, 'FF Adj Parameters'!$B$[CCJ_1kto2k_Row],        // 2.50
    IF(ccj_value<5000, 'FF Adj Parameters'!$B$[CCJ_2kto5k_Row],        // 3.50
    'FF Adj Parameters'!$B$[CCJ_gt5k_Row])))))))),                     // 5.00
    
    // 3. Apply count multiplier
    count_mult, 
    IF(ccj_count=0, 1.00,
    IF(ccj_count=1, 'FF Adj Parameters'!$B$[CCJ_1count_Row],           // 1.00
    IF(ccj_count<=3, 'FF Adj Parameters'!$B$[CCJ_2to3count_Row],       // 1.10
    'FF Adj Parameters'!$B$[CCJ_4pluscount_Row]))),                    // 1.25
    
    // 4. Final adjustment
    age_value_tier * count_mult
)
```

**Data Requirements:**
- Must have CCJ count (satisfied + unsatisfied)
- Must have CCJ total value (if available)
- Must have last CCJ date

**Testing:**
- No CCJ = 1.00x
- 1 CCJ, >6 years = 1.075x
- 1 CCJ, <2 years, £3,000 = 3.50x
- 3 CCJs, <2 years, £1,500 = 2.50x × 1.10 = 2.75x

---

#### 4. Loss Severity Formula
**Location:** LS Calculations sheet, Column 12 (Combined LS)

**Current Status:**
- Formula: ⚠️ Using additive (WRONG)

**Required Change:**

```excel
OLD (Row 5 example):
=J5+K5

NEW:
=1-((1-J5)*(1-K5))
```

Where:
- J5 = Market Loss Severity
- K5 = Originator Adjustment to LS

**Testing:**
- Market LS = 30%, Originator = 5%
- OLD: 30% + 5% = 35%
- NEW: 1-((1-0.30)×(1-0.05)) = 1-(0.70×0.95) = 33.5%

---

### Priority: IMPORTANT (Should complete)

#### 5. Income Multiple Adjustment
**Location:** FF Calculations sheet, Column for Income Multiple adjustment

**Current Status:**
- Parameters: ✅ Joint thresholds added
- Formula: ⚠️ Must add joint borrower logic

**Required Changes:**

```excel
=LET(
    num_borrowers, 'Loan Tape (S&P)'!Num_Debtors,
    primary_income, 'Loan Tape (S&P)'!Y5,
    secondary_income, 'Loan Tape (S&P)'!Z5,
    total_income, primary_income + secondary_income,
    balance, 'Loan Tape (S&P)'!M5,
    income_mult, balance / total_income,
    
    // Select thresholds
    low_thresh, IF(num_borrowers>1, 
                   'FF Adj Parameters'!$B$[Joint_Low_Row],      // 2.75
                   'FF Adj Parameters'!$B$[Single_Low_Row]),    // 3.5
    high_thresh, IF(num_borrowers>1,
                    'FF Adj Parameters'!$B$[Joint_High_Row],    // 3.25
                    'FF Adj Parameters'!$B$[Single_High_Row]),  // 5.0
    
    // Calculate adjustment
    IF(income_mult<low_thresh, 0.90,
    IF(income_mult<high_thresh, 1.00, 1.25))
)
```

**Simplified version (if no MIN logic):**
- Just use joint thresholds if num_borrowers > 1
- Use single thresholds if num_borrowers = 1

**Testing:**
- Single, 4.0x → 1.00x (neutral)
- Single, 6.0x → 1.25x (stress)
- Joint, 3.0x → 1.00x (neutral)
- Joint, 4.0x → 1.25x (stress)

---

#### 6. Seasoning Adjustment
**Location:** FF Calculations sheet, Column for Seasoning adjustment

**Current Status:**
- Parameters: ✅ Full 9-tier scale added
- Formula: ⚠️ Must update to reference new tiers

**Required Changes:**

```excel
=LET(
    seasoning_years, DATEDIF('Loan Tape (S&P)'!K5, 
                             'Control Panel'!$B$8, "Y"),
    
    IF(seasoning_years<5, 'FF Adj Parameters'!$B$[Seas_lt5_Row],      // 1.00
    IF(seasoning_years=5, 'FF Adj Parameters'!$B$[Seas_5yr_Row],      // 0.90
    IF(seasoning_years=6, 'FF Adj Parameters'!$B$[Seas_6yr_Row],      // 0.85
    IF(seasoning_years=7, 'FF Adj Parameters'!$B$[Seas_7yr_Row],      // 0.80
    IF(seasoning_years=8, 'FF Adj Parameters'!$B$[Seas_8yr_Row],      // 0.78
    IF(seasoning_years=9, 'FF Adj Parameters'!$B$[Seas_9yr_Row],      // 0.75
    IF(seasoning_years=10, 'FF Adj Parameters'!$B$[Seas_10yr_Row],    // 0.70
    IF(seasoning_years=11, 'FF Adj Parameters'!$B$[Seas_11yr_Row],    // 0.67
    'FF Adj Parameters'!$B$[Seas_12plusyr_Row]))))))))                // 0.65
)
```

**Testing:**
- 4 years = 1.00x
- 7 years = 0.80x
- 12+ years = 0.65x

---

#### 7. Interest Only Adjustment
**Location:** FF Calculations sheet, Column for IO adjustment

**Current Status:**
- Parameters: ✅ Full 5-tier scale added
- Formula: ⚠️ Must update to term-based tiers

**Required Changes:**

```excel
=LET(
    payment_method, 'Loan Tape (S&P)'!P5,
    occupancy, 'Loan Tape (S&P)'!N5,
    orig_date, 'Loan Tape (S&P)'!K5,
    maturity_date, 'Loan Tape (S&P)'!L5,
    cutoff_date, 'Control Panel'!$B$8,
    remaining_months, DATEDIF(cutoff_date, maturity_date, "M"),
    remaining_years, remaining_months / 12,
    
    // BTL exclusion
    is_btl, occupancy="Buy to Let",
    
    // If BTL or not IO, no adjustment
    IF(OR(is_btl, payment_method<>"Interest Only"), 1.00,
    
    // Otherwise apply term-based tiers
    IF(remaining_years<5, 'FF Adj Parameters'!$B$[IO_lt5_Row],         // 1.30
    IF(remaining_years<10, 'FF Adj Parameters'!$B$[IO_5to10_Row],      // 1.40
    IF(remaining_years<15, 'FF Adj Parameters'!$B$[IO_10to15_Row],     // 1.50
    IF(remaining_years<25, 'FF Adj Parameters'!$B$[IO_15to25_Row],     // 1.50
    'FF Adj Parameters'!$B$[IO_gt25_Row])))))                          // 1.60
)
```

**Testing:**
- Owner-occupied IO, 8 years remaining = 1.40x
- Owner-occupied IO, 30 years remaining = 1.60x
- BTL IO, any term = 1.00x (excluded)

---

### Priority: POOL-LEVEL (Add to Pool Summary)

#### 8. Geographic Concentration
**Location:** Pool Summary sheet, new row for Geo Concentration adjustment

**Required Implementation:**

```excel
// Create helper columns for each region
Region_Pct_London = SUMIF(Region_Column, "London", Balance_Column) / Total_Balance
Region_Pct_Scotland = SUMIF(Region_Column, "Scotland", Balance_Column) / Total_Balance
// ... for each region

// Reference population shares (create parameter table)
Pop_Share_London = 0.15    // 15% of UK population
Pop_Share_Scotland = 0.08  // 8% of UK population
// ... for each region

// Calculate excesses above 2x threshold
Excess_London = MAX(0, Region_Pct_London - (2 * Pop_Share_London))
Excess_Scotland = MAX(0, Region_Pct_Scotland - (2 * Pop_Share_Scotland))
// ... for each region

// Total excess concentration
Total_Excess = Excess_London + Excess_Scotland + ...

// Apply adjustment
Geo_Concentration_Multiplier = 1 + (Total_Excess * 0.10)  // Base 1.10x adjustment

// Apply to Pool WAFF
Adjusted_Pool_WAFF = Pool_WAFF_Before_Geo × Geo_Concentration_Multiplier
```

**Testing:**
- Even distribution = 1.00x (no adjustment)
- 40% in London (vs 15% population) = Material adjustment

---

#### 9. Small Pool Adjustment
**Location:** Pool Summary sheet, row for Small Pool adjustment

**Required Implementation:**

```excel
// Count loans in pool
Loan_Count = COUNTA(Loan_ID_Column)

// Lookup adjustment factor
Small_Pool_Multiplier = 
  IF(Loan_Count>=250, 'FF Adj Parameters'!$B$[SmPool_250plus_Row],    // 1.00
  IF(Loan_Count>=200, 'FF Adj Parameters'!$B$[SmPool_200to249_Row],   // 1.05
  IF(Loan_Count>=150, 'FF Adj Parameters'!$B$[SmPool_150to199_Row],   // 1.10
  IF(Loan_Count>=100, 'FF Adj Parameters'!$B$[SmPool_100to149_Row],   // 1.15
  IF(Loan_Count>=75, 'FF Adj Parameters'!$B$[SmPool_75to99_Row],      // 1.20
  IF(Loan_Count>=50, 'FF Adj Parameters'!$B$[SmPool_50to74_Row],      // 1.30
  IF(Loan_Count>=25, 'FF Adj Parameters'!$B$[SmPool_25to49_Row],      // 1.50
  'FF Adj Parameters'!$B$[SmPool_lt25_Row])))))))                     // 2.00

// Apply to Pool WAFF
Adjusted_Pool_WAFF = Pool_WAFF_Before_SmPool × Small_Pool_Multiplier
```

**Testing:**
- 300 loans = 1.00x (no adjustment)
- 120 loans = 1.15x
- 80 loans = 1.20x
- 40 loans = 1.50x

---

## 🧪 VALIDATION TESTS

### Test Case 1: Clean Prime Pool
**Characteristics:**
- Owner-occupied, repayment, prime credit
- Average LTV: 70%, Seasoning: 8 years
- No arrears, no CCJs, no HTB

**Expected:**
- LTV multiplier: ~0.87x
- Seasoning: 0.78x
- All other: 1.00x
- Net FF: ~0.68x of Base FF

### Test Case 2: Specialist Lender Pool
**Characteristics:**
- 30% HTB, 40% FTB
- Average LTV: 85%, Seasoning: 2 years
- 5% CCJs (recent, small amounts)
- 2% in 1-2 month arrears

**Expected:**
- HTB loans: 1.35x adjustment (vs 1.00x old)
- CCJ loans: ~1.80x adjustment (vs 1.30x old)
- Arrears: 3.00x-5.00x (vs 1.30x-1.45x old)
- Material increase in Pool WAFF

### Test Case 3: Small Regional Pool
**Characteristics:**
- 120 loans (small pool)
- 60% concentrated in single region
- Average credit quality

**Expected:**
- Small pool: 1.15x multiplier
- Geographic concentration: ~1.05x-1.10x
- Combined pool-level impact: +20-26%

---

## 📊 BEFORE/AFTER COMPARISON

Run a test pool through both v5.1 and v5.2 to see impact:

| Metric | v5.1 | v5.2 | Change |
|--------|------|------|--------|
| Clean prime WAFF | X.XX% | ~Same | Minimal |
| HTB-heavy pool | X.XX% | +25-35% | Material ↑ |
| Arrears/CCJ pool | X.XX% | +100-300% | Substantial ↑ |
| Small pool (<100) | X.XX% | +15-20% | Material ↑ |

---

## ✅ COMPLETION CHECKLIST

**Formula Updates:**
- [ ] HTB: FTB exclusion added
- [ ] Arrears: New 7-tier scale implemented
- [ ] CCJ: Age/value/count tiers implemented
- [ ] Loss Severity: Multiplicative formula
- [ ] Income Multiple: Joint thresholds added
- [ ] Seasoning: 9-tier scale implemented
- [ ] Interest Only: Term-based tiers implemented

**Pool-Level Adjustments:**
- [ ] Geographic Concentration calculation added
- [ ] Small Pool adjustment lookup added

**Testing:**
- [ ] Tested HTB loan (1.35x, no FTB benefit)
- [ ] Tested CCJ loan (correct tier)
- [ ] Tested arrears loan (correct scale)
- [ ] Tested LS formula (multiplicative result)
- [ ] Tested small pool (<250 loans)
- [ ] Compared v5.1 vs v5.2 results

**Documentation:**
- [ ] Updated transaction summary with methodology notes
- [ ] Documented any pool-specific adjustments
- [ ] Reviewed all parameter values

---

## 🎓 KEY PRINCIPLES

**1. Parameters are correct, formulas need updating**
- v5.2 has all the right VALUES
- Just need to REFERENCE them correctly in formulas

**2. Joint borrower logic is critical**
- Income Multiple uses different thresholds
- CCJ aggregates across borrowers
- Don't double-count

**3. Pool-level adjustments are separate**
- Geographic Concentration: Applied in Pool Summary
- Small Pool: Applied in Pool Summary
- Not loan-level

**4. Test incrementally**
- Update one adjustment at a time
- Test each change
- Compare results

---

## 📞 NEED HELP?

**Common Issues:**

**"My CCJ formula is too complex"**
→ Start with age-based tiers only, add value tiers later

**"I don't have CCJ values, only counts"**
→ Use age-based tiers only, set count multiplier manually

**"Geographic concentration is confusing"**
→ Start simple: London vs Rest of UK only

**"Small pool - where exactly does it apply?"**
→ After loan-level WAFF calculated, multiply ENTIRE pool by factor

---

## 🎉 YOU'RE READY!

After completing these formula updates, your model will be:

✅ **100% S&P Methodology Compliant** (parameters + formulas)  
✅ **Submission Grade** (suitable for rating agency use)  
✅ **Audit Defensible** (all values traceable to S&P criteria)  
✅ **Investor Ready** (professional quality outputs)

**Good luck with your implementation!**
